from setuptools import setup

setup(
    name= "paquete1",
    version= "1.0",
    description= "Paquete para iniciar menu y crear clientes",
    author= "Nicolás Godoy",
    author_email="nicolasgastongodoy@gmail.com",

    packages= ["paquete1"]

)